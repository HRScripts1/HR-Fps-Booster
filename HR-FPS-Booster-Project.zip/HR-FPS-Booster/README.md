# HR FPS Booster (Fabric)

Minecraft Java 1.21.11, client-side, Java 21.


This starter mod automatically sets particles to Minimal when Minecraft starts and saves the setting. It does not promise a fixed FPS gain; effects depend on hardware, scenes, and other mods.


## Build the JAR

1. Install Java 21.
2. Install Gradle 8.14+ (or use a Gradle wrapper).
3. In this folder, run `gradle build`.
4. The JAR is output under `build/libs/HR-FPS-Booster-1.0.0.jar` (the exact suffix may vary).
5. Copy the JAR to your Minecraft `mods` folder. Ensure Fabric Loader is installed for 1.21.11.
